package model.partita;

public enum Azione {
	MOVIMENTO, INDAGINE, ACCUSA, TACCUINO, BLOCCONOTE;
}
