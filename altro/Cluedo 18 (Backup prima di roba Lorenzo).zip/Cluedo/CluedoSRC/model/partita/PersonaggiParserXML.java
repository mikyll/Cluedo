package model.partita;

public class PersonaggiParserXML {

}
