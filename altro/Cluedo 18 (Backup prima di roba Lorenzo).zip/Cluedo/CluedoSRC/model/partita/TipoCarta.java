package model.partita;

public enum TipoCarta {
	ARMA, SOSPETTATO, STANZA;
}
