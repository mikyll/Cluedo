package model.partita;

public enum Difficolta {
	FACILE, DIFFICILE, GOD_MODE;
}
