package model.partita;

public class Preambolo {

}
