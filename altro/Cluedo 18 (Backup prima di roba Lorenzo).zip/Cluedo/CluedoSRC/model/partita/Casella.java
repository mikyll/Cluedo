package model.partita;

public class Casella {

}
