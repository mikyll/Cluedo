package model.menu;

public class Utente {
	private String username;
	
	public Utente (String username)
	{
		this.username = username;
	}
	
	public String getUsername() {return this.username;}
}
