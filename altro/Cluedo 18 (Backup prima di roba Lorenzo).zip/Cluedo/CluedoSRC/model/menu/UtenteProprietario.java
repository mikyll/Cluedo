package model.menu;

public class UtenteProprietario {

}
