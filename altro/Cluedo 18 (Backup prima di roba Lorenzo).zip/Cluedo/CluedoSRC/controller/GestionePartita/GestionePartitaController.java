package controller.GestionePartita;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import _clientApplicazione.ClientApplicazione;
import controller.GestioneTurno.PreparazioneController;
import controller.GestioneTurno.StrumentiController;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Screen;
import javafx.stage.Stage;
import model.impostazioni.Impostazioni;
import model.impostazioni.MusicPlayer;
import model.partita.Difficolta;
import model.partita.Giocatore;
import model.partita.Partita;

public class GestionePartitaController implements IGestionePartita{
	// CONTROLLERS
	@FXML private StrumentiController strumentiController;
	
	private Stage stage;
	// TOP
	@FXML private MenuItem menuItemEsci;
	@FXML private MenuItem menuItemFullScreen;
	// CENTER-LEFT
	@FXML private ListView<String> listViewGiocatori;
	@FXML private ListView<ImageView> listViewColori;
	// CENTER_RIGHT
	@FXML private HBox hboxCentrale;
	@FXML private VBox vboxFase;
	
	// BOTTOM
	@FXML private TextField textFieldUsername;
	@FXML private TextField textFieldPersonaggio;
	@FXML private TextField textFieldNumeroTurno;
	@FXML private TextField textFieldColore;
	@FXML private ImageView imageViewColore;
	
	@FXML private Button buttonMovimento;
	@FXML private Button buttonIndagine;
	@FXML private Button buttonAccusa;
	@FXML private Button buttonFineTurno;
	@FXML private Button buttonApriTaccuino;
	@FXML private Button buttonApriBloccoNote;
	
	// BLOCCO NOTE
	@FXML private TextArea textAreaBloccoNote;
	@FXML private Button buttonSalva;
	@FXML private Button buttonChiudiSenzaSalvare;
	
	

	private Impostazioni impostazioni;
	private NumberFormat formatterNoFractionDigits;	// per percentuali (nessun decimale)
	private MusicPlayer musicPlayer;
	// ==================================== MODEL
	@FXML private Partita partita;
	
	// NB: ci sono due costruttori: uno con parametri, invocato una volta (da MenuController), che inizializza musica ed oggetto Partita
	public GestionePartitaController(Impostazioni impostazioni, Stage stage, int numeroGiocatori, String difficolta)
	{
		this.impostazioni = impostazioni;
		this.stage = stage;
		
		this.formatterNoFractionDigits = NumberFormat.getInstance();
		this.formatterNoFractionDigits.setMaximumFractionDigits(0);
		
		String musicTitle = "George Arkomanis - Relaxation In Mystery (Game).mp3";
		this.musicPlayer = MusicPlayer.getIstanza(musicTitle); // NB: ritorner� l'istanza gi� creata nel metodo "avviaPartita"
		this.musicPlayer.getMediaPlayer().play();
		this.musicPlayer.getMediaPlayer().setVolume(this.impostazioni.getVolumeMusica() / 100);
		this.musicPlayer.getMediaPlayer().setCycleCount(Integer.MAX_VALUE); // per ripetere la traccia ad oltranza
		if(this.impostazioni.isEnabledMusica())
		{
			this.musicPlayer.getMediaPlayer().play();
			System.out.println("Music playing (" + this.formatterNoFractionDigits.format(this.impostazioni.getVolumeMusica()) + "%): " + musicTitle);
		}
		else this.musicPlayer.getMediaPlayer().stop();
		
		
		// Creazione oggetto Partita		
		//partita = new Partita(numeroGiocatori, Difficolta.FACILE); // test
		this.partita = Partita.getInstance(numeroGiocatori, Difficolta.FACILE);
	}
	
	public GestionePartitaController() {}
	
	@FXML public void initialize() 
	{
		this.textFieldUsername.setText("Giocatore");

		// partita = Partita.getIstanza(numeroGiocatori, Difficolta.valueOf(difficolta));
		try {this.avviaPreparazione();} catch (IOException e) {e.printStackTrace();}
		
		// System.out.println("init"); // TEST
		
		// creo una lista di Stringhe contentente gli username dei giocatori
		List<String> giocatori = new ArrayList<String>(this.partita.getGiocatori().size());
		
		// popolo la lista appena creata
		for(Giocatore g : this.partita.getGiocatori())
			giocatori.add(g.getUsername());
		
		// la aggiungo alla listView mostrata
		this.listViewGiocatori.setItems(FXCollections.observableArrayList(giocatori));
		this.listViewGiocatori.setFixedCellSize(30);
		this.listViewColori.setFixedCellSize(30);
	}
	
// MENU
	@FXML public void close(ActionEvent event)
	{
		Platform.exit();
		System.exit(0);
	}
	@FXML public void toggleFullScreen(ActionEvent event)
	{
		this.stage.setFullScreen(!this.stage.isFullScreen());
	}
	@FXML public void prova(ActionEvent event)
	{
		this.listViewGiocatori.getItems().add((String) "MarioMarioMario4");
	}
	@FXML public void terminaPartita(ActionEvent event) throws IOException
	{
		System.out.println("[Sistema] Partita terminata.");
		
		// ELIMINARE L'ISTANZA DELLA PARTITA (altrimenti rimane per le partite future!)
		Partita.deleteInstance();
		
		this.musicPlayer.getMediaPlayer().stop();
		this.musicPlayer = null;
		MusicPlayer.createNewMusicPlayer("David Fesliyan - Unfolding Revelation (Menu).mp3");
		
		// mostra HomeUtente
		FXMLLoader loader = new FXMLLoader(ClientApplicazione.class.getResource("/view/InterfacciaMenu/HomeUtente.fxml"));
		//Stage stage = (Stage) buttonApriTaccuino.getScene().getWindow();
		// passare music player a gestioneMenu?
		AnchorPane viewTutorial = (AnchorPane) loader.load();
		Scene scene = new Scene(viewTutorial);
		scene.getStylesheets().add(getClass().getResource("/resources/styles/application.css").toExternalForm());
		this.stage.setScene(scene);
		this.stage.setFullScreen(false); // non serve ma lo lascio per sicurezza
		
		// imposta la finestra al centro dello schermo
		javafx.geometry.Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();
		stage.setX((primScreenBounds.getWidth() - stage.getWidth()) / 2);
		stage.setY((primScreenBounds.getHeight() - stage.getHeight()) / 2);
		System.out.println("Dimensioni finestra: " + stage.getWidth() + "x" + stage.getHeight());
	}
	
// PREPARAZIONE
	private void avviaPreparazione() throws IOException
	{
		System.out.println("[Sistema] fase di preparazione.");
		
		
		FXMLLoader loader = new FXMLLoader(ClientApplicazione.class.getResource("/view/InterfacciaPartita/ViewPreparazione.fxml"));
		loader.setController(new PreparazioneController());
		VBox viewPreparazione = (VBox) loader.load();
		
		this.vboxFase.getChildren().add(viewPreparazione);
	}
	
// MOVIMENTO
	public void selezionaMovimento(ActionEvent event) throws IOException
	{
		System.out.println("[Sistema] Giocatore ha selezionato Movimento.");
		
		if(this.vboxFase.getChildren().size() > 0)
			this.vboxFase.getChildren().remove(0);
		
		FXMLLoader loader = new FXMLLoader(ClientApplicazione.class.getResource("/view/InterfacciaPartita/ViewMovimento.fxml"));
		VBox viewMovimento = (VBox) loader.load();
		this.vboxFase.getChildren().add(viewMovimento);
		
		// disabilitare bottoni
		this.buttonMovimento.setDisable(true);
		this.buttonIndagine.setDisable(true);
		this.buttonAccusa.setDisable(true);
		this.buttonApriTaccuino.setDisable(true);
		this.buttonApriBloccoNote.setDisable(true);
	}
	@FXML public void selezionaIndagine(ActionEvent event) throws IOException
	{
		
	}
	@FXML public void selezionaAccusa(ActionEvent event) throws IOException
	{
		
	}
	@FXML public void selezionaFineTurno(ActionEvent event) throws IOException
	{
		
	}
// STRUMENTI
	@FXML public void selezionaTaccuino(ActionEvent event) throws IOException
	{
		System.out.println("[Sistema] Giocatore ha aperto il Taccuino.");
		
		if(this.vboxFase.getChildren().size() > 0)
			this.vboxFase.getChildren().remove(0);
		
		FXMLLoader loader = new FXMLLoader(ClientApplicazione.class.getResource("/view/InterfacciaPartita/ViewTaccuino.fxml"));
		VBox viewTaccuino = (VBox) loader.load();
		this.vboxFase.getChildren().add(viewTaccuino);
		
		// disabilitare bottoni
		this.buttonMovimento.setDisable(true);
		this.buttonIndagine.setDisable(true);
		this.buttonAccusa.setDisable(true);
		this.buttonFineTurno.setDisable(true);
		this.buttonApriTaccuino.setDisable(true);
		this.buttonApriBloccoNote.setDisable(true);
	}
	@FXML public void selezionaBloccoNote(ActionEvent event) throws IOException
	{
		System.out.println("[Sistema] Giocatore ha aperto il BloccoNote.");
		
		if(this.vboxFase.getChildren().size() > 0)
			this.vboxFase.getChildren().remove(0);
		
		FXMLLoader loader = new FXMLLoader(ClientApplicazione.class.getResource("/view/InterfacciaPartita/ViewBloccoNote.fxml"));
		VBox viewBloccoNote = (VBox) loader.load();
		this.vboxFase.getChildren().add(viewBloccoNote);
		
		// disabilitare bottoni
		this.buttonMovimento.setDisable(true);
		this.buttonIndagine.setDisable(true);
		this.buttonAccusa.setDisable(true);
		this.buttonFineTurno.setDisable(true);
		this.buttonApriTaccuino.setDisable(true);
		this.buttonApriBloccoNote.setDisable(true);
	}
	
	
	public Partita getPartita()
	{
		return this.partita;
	}
	
}
