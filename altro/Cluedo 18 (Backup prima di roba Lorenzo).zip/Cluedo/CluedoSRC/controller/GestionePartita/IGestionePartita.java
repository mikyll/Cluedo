package controller.GestionePartita;

public interface IGestionePartita {

}
