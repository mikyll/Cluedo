package controller.GestioneMenu;

public interface IGestioneMenu {

}
