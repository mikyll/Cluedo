package controller.GestioneTurno;

public interface IGestioneTurno {

}
